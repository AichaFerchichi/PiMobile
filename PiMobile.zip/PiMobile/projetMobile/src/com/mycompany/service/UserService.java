/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.service;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkManager;
import com.codename1.ui.Dialog;
import com.mycompany.entity.Garderies;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.mycompany.entity.User;
/**
 *
 * @author MacBook
 */
public class UserService {

    public UserService() {
    }
     public void ajoutUser(User ta) {
        ConnectionRequest con = new ConnectionRequest();
        String Url = "http://localhost:8888/houfinal/Utopia/projetSymfonyPIDEV/web/app_dev.php/ajoutUser/" + ta.getUsername() + "/" + ta.getEmail()+ "/" + ta.getPassword();
        con.setUrl(Url);

        System.out.println("tt");

        con.addResponseListener(e -> {
            String str = new String(con.getResponseData());
            System.out.println(str);
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
    }
   
    /*public ArrayList<User> log(User ta) {
         ArrayList<User> listTasks = new ArrayList<>();
        ConnectionRequest con = new ConnectionRequest();
        String Url = "http://localhost:8888/houfinal/Utopia/projetSymfonyPIDEV/web/app_dev.php/log/" + ta.getUsername() + "/" + ta.getPassword();
        con.setUrl(Url);

        System.out.println("tt");

        con.addResponseListener(e -> {
            JSONParser jsonp = new JSONParser();
                try {
                    Map<String, Object> tasks = jsonp.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
                    System.out.println(tasks);
                    List<Map<String, Object>> list = (List<Map<String, Object>>) tasks.get("root");
                     if(list!=null){
                    for (Map<String, Object> obj : list) {
                        System.out.println(obj);
                        User task = new User();
                        
                      
//float id = Float.parseFloat(obj.get("id").toString());
                      
                       
                        task.setUsername(obj.get("username").toString());
                          task.setPassword(obj.get("password").toString());
                         
     task.setId((int) obj.get("id"));
                        listTasks.add(task);

                    }}
                    else{
                    Dialog.show("Invalide", "Vérifiez vos paramètres ", "OK", "Cancel");
            
                } } catch (IOException ex) {
                }
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        return listTasks;
    }*/
      public ArrayList<User> log(User ta) {
        ArrayList<User> listTasks = new ArrayList<>();
        ConnectionRequest con = new ConnectionRequest();
         String Url = "http://localhost:8888/houfinal/Utopia/projetSymfonyPIDEV/web/app_dev.php/log/" + ta.getUsername() + "/" + ta.getPassword();
        con.setUrl(Url);
        con.addResponseListener(e->{
                JSONParser jsonp = new JSONParser();
                try {
                    Map<String, Object> tasks = jsonp.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
                    System.out.println(tasks);
                    List<Map<String, Object>> list = (List<Map<String, Object>>) tasks.get("root");
                    for (Map<String, Object> obj : list) {
                        System.out.println(obj);
                        User garderie = new User();
                        //float nb_place_dispo = Float.parseFloat(obj.get("nb_place_dispo").toString());
                        
//float idGarderie = Float.parseFloat(obj.get("id").toString());
                     
                        
garderie.setUsername(obj.get("username").toString());
garderie.setPassword(obj.get("password").toString());
                      garderie.setEmail(obj.get("email").toString());
                     //  garderie.setId((int) idGarderie);

                        
                       
                        
                        listTasks.add(garderie);

                    }
                } catch (IOException ex) {
                }

            
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        return listTasks;
    }
      
    public ArrayList<User> RecupererUserById() {
         ArrayList<User> listTasks = new ArrayList<>();
        ConnectionRequest con = new ConnectionRequest();
        String Url = "http://localhost/houfinal/Utopia/projetSymfonyPIDEV/web/app_dev.php/RecupererUserById/" + User.idUserConnected;
        con.setUrl(Url);

        System.out.println("tt");

        con.addResponseListener(e -> {
            JSONParser jsonp = new JSONParser();
                try {
                    Map<String, Object> tasks = jsonp.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
                    System.out.println(tasks);
                    List<Map<String, Object>> list = (List<Map<String, Object>>) tasks.get("root");
                    if(list!=null){
                    for (Map<String, Object> obj : list) {
                        System.out.println(obj);
                        User task = new User();

                        
                        float id = Float.parseFloat(obj.get("id").toString());
                       
                        task.setUsername(obj.get("username").toString());
                          task.setPassword(obj.get("password").toString());
                           task.setId((int) id);


                        listTasks.add(task);

                    }}
                    else{
                    Dialog.show("Invalide", "Vérifiez vos paramètres ", "OK", "Cancel");
            }
                } catch (IOException ex) {
                }
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        return listTasks;
    }
    public ArrayList<User> profile(String email) {
        ArrayList<User> listTasks = new ArrayList<>();
        ConnectionRequest con = new ConnectionRequest();
         String Url = "http://localhost:8888/houfinal/Utopia/projetSymfonyPIDEV/web/app_dev.php/profile/" + email;
        con.setUrl(Url);
        con.addResponseListener(e->{
                JSONParser jsonp = new JSONParser();
                try {
                    Map<String, Object> tasks = jsonp.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
                    System.out.println(tasks);
                    List<Map<String, Object>> list = (List<Map<String, Object>>) tasks.get("root");
                    for (Map<String, Object> obj : list) {
                        System.out.println(obj);
                        User garderie = new User();
                        //float nb_place_dispo = Float.parseFloat(obj.get("nb_place_dispo").toString());
                        
//float idGarderie = Float.parseFloat(obj.get("id").toString());
                     
                        
garderie.setUsername(obj.get("username").toString());
garderie.setPassword(obj.get("password").toString());
   garderie.setImage(obj.get("image").toString());
                      garderie.setEmail(obj.get("email").toString());
                     //  garderie.setId((int) idGarderie);

                        
                       
                        
                        listTasks.add(garderie);

                    }
                } catch (IOException ex) {
                }

            
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        return listTasks;
    }
}
